//
// Created by Konrad Rodzik on 5/18/15.
// Copyright (c) 2015 Qordoba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Qordoba)
@property (nonatomic, assign) BOOL supportForHardcodedStrings;

- (BOOL)isHardcodedStringsSupported;

- (void)enableHardcodedStringsSupport:(BOOL)flag;
@end